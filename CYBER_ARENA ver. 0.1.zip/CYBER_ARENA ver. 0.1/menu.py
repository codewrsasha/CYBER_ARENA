# menu.py
import pygame
import sys
from settings import Settings
from ui import Button, CyberText, NeonBorder

class Menu:
    def __init__(self, screen):
        self.screen = screen
        self.settings = Settings()
        self.clock = pygame.time.Clock()
        self.font_large = pygame.font.Font(None, 74)
        self.font_medium = pygame.font.Font(None, 50)
        self.font_small = pygame.font.Font(None, 36)
        
        # Анимация
        self.time = 0
        
    def draw_background(self):
        """Рисует киберпанк фон с эффектом матрицы"""
        self.screen.fill(self.settings.CYBER_BLACK)
        
        # Рисуем линии как в матрице
        for i in range(0, self.settings.screen_width, 30):
            x = i + (self.time % 30)
            alpha = (pygame.time.get_ticks() // 100 + i) % 255
            color = (0, min(255, alpha // 2), 0)
            pygame.draw.line(self.screen, color, (x, 0), (x, self.settings.screen_height), 1)
            
        self.time += 1
        
    def main_menu(self):
        while True:
            self.clock.tick(self.settings.FPS)
            self.draw_background()
            
            # Заголовок
            title = CyberText("CYBER ARENA", 74, self.settings.CYBER_BLUE, glow=True)
            title_rect = title.get_rect(center=(self.settings.screen_width // 2, 100))
            title.draw(self.screen, title_rect.topleft)
            
            # Подзаголовок
            subtitle = CyberText("VIRUS PROTOCOL", 36, self.settings.CYBER_PINK)
            subtitle_rect = subtitle.get_rect(center=(self.settings.screen_width // 2, 170))
            subtitle.draw(self.screen, subtitle_rect.topleft)
            
            # Кнопки
            play_button = Button(self.settings.screen_width // 2, 300, 
                                "> ИНИЦИАЛИЗИРОВАТЬ <", self.font_medium)
            settings_button = Button(self.settings.screen_width // 2, 400,
                                   "> НАСТРОЙКИ <", self.font_medium)
            exit_button = Button(self.settings.screen_width // 2, 500,
                               "> ВЫХОД <", self.font_medium)
            
            # Обработка событий
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if play_button.is_clicked(event.pos):
                        return "play"
                    elif settings_button.is_clicked(event.pos):
                        return "settings"
                    elif exit_button.is_clicked(event.pos):
                        pygame.quit()
                        sys.exit()
                        
            # Отрисовка кнопок
            play_button.draw(self.screen)
            settings_button.draw(self.screen)
            exit_button.draw(self.screen)
            
            pygame.display.flip()
            
    def settings_menu(self):
        while True:
            self.clock.tick(self.settings.FPS)
            self.draw_background()
            
            # Заголовок
            title = CyberText("НАСТРОЙКИ СИСТЕМЫ", 50, self.settings.CYBER_GREEN)
            title_rect = title.get_rect(center=(self.settings.screen_width // 2, 80))
            title.draw(self.screen, title_rect.topleft)
            
            # Параметры разрешения
            resolutions = [(1024, 768), (1280, 720), (1920, 1080)]
            current_res = f"{self.settings.screen_width} x {self.settings.screen_height}"
            
            res_text = CyberText(f"РАЗРЕШЕНИЕ: {current_res}", 36, self.settings.CYBER_BLUE)
            res_rect = res_text.get_rect(center=(self.settings.screen_width // 2, 200))
            res_text.draw(self.screen, res_rect.topleft)
            
            # Кнопки изменения разрешения
            prev_res = Button(self.settings.screen_width // 2 - 150, 280, "<", self.font_small)
            next_res = Button(self.settings.screen_width // 2 + 150, 280, ">", self.font_small)
            
            # Кнопка назад
            back_button = Button(self.settings.screen_width // 2, 500,
                               "> НАЗАД <", self.font_medium)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if back_button.is_clicked(event.pos):
                        self.settings.save_settings()
                        return
                    elif prev_res.is_clicked(event.pos):
                        current_index = resolutions.index((self.settings.screen_width, 
                                                          self.settings.screen_height))
                        new_index = (current_index - 1) % len(resolutions)
                        self.settings.current["screen_width"] = resolutions[new_index][0]
                        self.settings.current["screen_height"] = resolutions[new_index][1]
                    elif next_res.is_clicked(event.pos):
                        current_index = resolutions.index((self.settings.screen_width, 
                                                          self.settings.screen_height))
                        new_index = (current_index + 1) % len(resolutions)
                        self.settings.current["screen_width"] = resolutions[new_index][0]
                        self.settings.current["screen_height"] = resolutions[new_index][1]
                        
            prev_res.draw(self.screen)
            next_res.draw(self.screen)
            back_button.draw(self.screen)
            
            pygame.display.flip()
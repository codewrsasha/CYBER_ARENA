# player.py
import pygame
import math
import os

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        
        # Загрузка изображения игрока
        image_path = os.path.join("assets", "images", "player.png")
        try:
            # Загружаем изображение и конвертируем для лучшей производительности
            original_image = pygame.image.load(image_path).convert_alpha()
            # Масштабируем до нужного размера (например, 48x48)
            self.image = pygame.transform.scale(original_image, (48, 48))
        except FileNotFoundError:
            # Если файл не найден, создаем заглушку
            print(f"Внимание: файл {image_path} не найден. Используется заглушка.")
            self.image = pygame.Surface((48, 48))
            self.image.fill((0, 255, 255))  # Голубой цвет робота


        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
        # Параметры робота
        self.speed = 5
        self.health = 100
        self.max_health = 100
        self.energy = 100
        self.max_energy = 100
        self.damage = 10
        self.shoot_cooldown = 0
        self.shoot_delay = 200  # миллисекунды
        
        # Для анимации
        self.last_shot = 0
        self.direction = "down"
        
    def update(self):
        # Управление
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            dy -= self.speed
            self.direction = "up"
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            dy += self.speed
            self.direction = "down"
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            dx -= self.speed
            self.direction = "left"
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            dx += self.speed
            self.direction = "right"
            
        # Диагональное движение
        if dx != 0 and dy != 0:
            dx *= 0.7071  # нормализация диагональной скорости
            dy *= 0.7071
            
        self.rect.x += dx
        self.rect.y += dy
        
        # Обновление кулдауна стрельбы
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
            
    def shoot(self):
        """Создает выстрел в направлении мыши"""
        if self.shoot_cooldown == 0:
            self.shoot_cooldown = self.shoot_delay
            return True
        return False
    
    def take_damage(self, amount):
        self.health -= amount
        return self.health <= 0
    
    def draw_ui(self, screen, camera):
        # Отрисовка полоски здоровья
        health_bar_width = 50
        health_bar_height = 6
        health_percent = self.health / self.max_health
        
        # Позиция над игроком
        bar_x = self.rect.x + (self.rect.width - health_bar_width) // 2
        bar_y = self.rect.y - 10
        
        # Применяем камеру
        bar_rect = pygame.Rect(bar_x, bar_y, health_bar_width, health_bar_height)
        bar_rect = camera.apply(bar_rect)
        
        # Рисуем фон
        pygame.draw.rect(screen, (60, 60, 60), bar_rect)
        # Рисуем здоровье
        health_rect = pygame.Rect(bar_x, bar_y, 
                                 health_bar_width * health_percent, health_bar_height)
        health_rect = camera.apply(health_rect)
        pygame.draw.rect(screen, (0, 255, 100), health_rect)
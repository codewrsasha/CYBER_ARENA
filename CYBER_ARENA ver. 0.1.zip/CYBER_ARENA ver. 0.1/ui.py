# ui.py
import pygame
from settings import Settings

class CyberText:
    def __init__(self, text, size, color, glow=False):
        self.settings = Settings()
        self.text = text
        self.size = size
        self.color = color
        self.glow = glow
        self.font = pygame.font.Font(None, size)
        self.render()
        
    def render(self):
        # Основной текст
        self.text_surface = self.font.render(self.text, True, self.color)
        
        # Эффект свечения
        if self.glow:
            self.glow_surface = self.font.render(self.text, True, self.settings.CYBER_BLUE)
            self.glow_surface.set_alpha(128)
            
    def draw(self, screen, pos):
        if self.glow:
            # Рисуем свечение
            for offset in [(2, 2), (-2, -2), (2, -2), (-2, 2)]:
                screen.blit(self.glow_surface, 
                           (pos[0] + offset[0], pos[1] + offset[1]))
        screen.blit(self.text_surface, pos)
        
    def get_rect(self, **kwargs):
        return self.text_surface.get_rect(**kwargs)

class Button:
    def __init__(self, x, y, text, font, color=None):
        self.settings = Settings()
        self.text = text
        self.font = font
        self.color = color or self.settings.CYBER_PURPLE
        self.hover_color = self.settings.CYBER_BLUE
        
        self.text_surface = font.render(text, True, self.color)
        self.rect = self.text_surface.get_rect(center=(x, y))
        self.hovered = False
        
    def draw(self, screen):
        color = self.hover_color if self.hovered else self.color
        text_surface = self.font.render(self.text, True, color)
        
        # Эффект пульсации при наведении
        if self.hovered:
            pulse = (pygame.time.get_ticks() % 1000) / 1000
            scale = 1 + pulse * 0.1
            # Упрощенная пульсация без изменения размера шрифта
            pass
            
        screen.blit(text_surface, self.rect)
        
        # Рисуем рамку при наведении
        if self.hovered:
            pygame.draw.rect(screen, color, self.rect.inflate(20, 10), 2)
            
    def is_clicked(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)
    
    def update(self, mouse_pos):
        self.hovered = self.rect.collidepoint(mouse_pos)

class NeonBorder:
    def __init__(self, rect, color, thickness=2, pulse=False):
        self.rect = rect
        self.color = color
        self.thickness = thickness
        self.pulse = pulse
        self.time = 0
        
    def draw(self, screen):
        if self.pulse:
            self.time += 1
            alpha = abs((self.time % 60) - 30) * 8.5  # Пульсация от 0 до 255
            
            # Создаем поверхность с альфа-каналом
            border_surf = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
            color_with_alpha = (*self.color, int(alpha))
            pygame.draw.rect(border_surf, color_with_alpha, 
                           border_surf.get_rect(), self.thickness)
            screen.blit(border_surf, self.rect)
        else:
            pygame.draw.rect(screen, self.color, self.rect, self.thickness)